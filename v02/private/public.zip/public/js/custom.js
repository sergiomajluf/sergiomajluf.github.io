$(function() {

    $("#draggableCell").draggable({
        handle: "p",
        containment: "#containment-wrapper",
        scroll: false
    });

    $("#area_q1").droppable({
        accept: "#draggableCell",
        activeClass: "ui-state-hover",
        hoverClass: "ui-state-active",
        drop: function(event, ui) {
            $(this).addClass("answered");
            $("#draggableCell").addClass("answeredQ1");
            //console.log("Answered Q1");
            $('#myModalQuestion01').modal('show');

            $("#area_q2").droppable({
                accept: "#draggableCell",
                activeClass: "ui-state-hover",
                hoverClass: "ui-state-active",
                drop: function(event, ui) {
                    $(this).addClass("answered");
                    //$("#draggableCell").removeClass("answeredQ1").
                    $("#draggableCell").addClass("answeredQ2");
                    console.log("Answered Q2");
                    $('#myModalQuestion02').modal('show');

                    $("#area_q3").droppable({
                        accept: "#draggableCell",
                        activeClass: "ui-state-hover",
                        hoverClass: "ui-state-active",
                        drop: function(event, ui) {
                            $(this).addClass("answered");
                            //$("#draggableCell").removeClass("answeredQ2").
                            $("#draggableCell").addClass("answeredQ3");
                            console.log("Answered Q3");
                            $('#myModalQuestion03').modal('show');

                            $("#area_q4").droppable({
                                accept: "#draggableCell",
                                activeClass: "ui-state-hover",
                                hoverClass: "ui-state-active",
                                drop: function(event, ui) {
                                    $(this).addClass("answered");
                                    $("#draggableCell").removeClass("answeredQ3").
                                    $("#draggableCell").addClass("answeredQ4");
                                    console.log("Answered Q4");
                                    $('#myModalQuestion04').modal('show');
                                }
                            });
                        }
                    });
                }
            });
        }
    });



});